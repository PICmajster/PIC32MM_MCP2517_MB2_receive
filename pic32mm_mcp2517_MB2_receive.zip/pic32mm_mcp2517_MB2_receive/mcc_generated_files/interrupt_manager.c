/**
  System Interrupts Generated Driver File 

  @Company:
    Microchip Technology Inc.

  @File Name:
    interrupt_manager.h

 
*/

/**
    Section: Includes
*/
#include <xc.h>
#include <proc/p32mm0256gpm048.h>

/**
    void INTERRUPT_Initialize (void)
*/
void INTERRUPT_Initialize (void)
{
    // Enable Multi Vector Configuration
    INTCONbits.MVEC = 1;
    
    //    TI: Timer 2
    //    Priority:
        IPC4bits.T2IP = 3;
    //    Sub Priority:
        IPC4bits.T2IS = 0;
        
         
        /*CN PORTA*/
        IPC2bits.CNAIP = 2; /*priority*/
        IPC2bits.CNAIS = 1; /*sub priority*/
        
        IFS0CLR = 1 << _IFS0_CNAIF_POSITION  ; /*clear flag*/
        CNFAbits.CNFA2 = 0 ; /*clear status*/
        /*ON Interrupt CN*/
        IEC0bits.CNAIE = 1;
        
}


