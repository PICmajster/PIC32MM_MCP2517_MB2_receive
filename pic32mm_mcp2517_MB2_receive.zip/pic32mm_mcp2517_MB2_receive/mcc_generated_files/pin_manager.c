/**
  System Interrupts Generated Driver File 

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.c

  */


/**
    Section: Includes
*/
#include <xc.h>
#include <proc/p32mm0256gpm048.h>
#include "pin_manager.h"
#include "mcc.h"

/**
    void PIN_MANAGER_Initialize(void)
*/
void PIN_MANAGER_Initialize(void)
{
    /****************************************************************************
     * Setting the Output Latch SFR(s)
     ***************************************************************************/
    LATA = 0x0000;
    LATB = 0x0000;
    LATC = 0x0000;
    LATD = 0x0000;

    /****************************************************************************
     * Setting the GPIO Direction SFR(s)
     ***************************************************************************/
    TRISA = 0x82DF;
    TRISB = 0xA3BF;
    TRISC = 0x13C7;
    TRISD = 0x0000;

    /****************************************************************************
     * Setting the Weak Pull Up and Weak Pull Down SFR(s)
     ***************************************************************************/
    CNPDA = 0x0000;
    CNPDB = 0x0000;
    CNPDC = 0x0000;
    CNPDD = 0x0000;
    CNPUA = 0x0004;//4
    CNPUB = 0x0000;
    CNPUC = 0x0102;
    CNPUD = 0x0000;

    /****************************************************************************
     * Setting the Open Drain SFR(s)
     ***************************************************************************/
    ODCA = 0x0000;
    ODCB = 0x0000;
    ODCC = 0x0000;
    ODCD = 0x0000;

    /****************************************************************************
     * Setting the Analog/Digital Configuration SFR(s)
     ***************************************************************************/
    ANSELA = 0x000B;
    ANSELB = 0x001C;
    ANSELC = 0x0001;
    /****************************************************************************
     * Setting the CHANGE NOTIFICATION CONTROL FOR PORTx
     ***************************************************************************/
    
    /*Detects a negative transition only (from 1 to 0)*/
    CNCONAbits.CNSTYLE = 1; 
    CNEN1Abits.CNIE1A2 = 1;
    CNEN0Abits.CNIE0A2 = 0;
    CNCONAbits.ON = 1; /*Enable CN for PORTA*/
    
    
}

